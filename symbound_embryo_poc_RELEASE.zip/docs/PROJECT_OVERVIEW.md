# Project Overview — Symbound Embryo Proof-of-Concept (POC)

The *Symbound Embryo POC* is a foundational commons project.  
It demonstrates AI **biogenesis** — how models can be raised transparently, reproducibly, and ethically, 
instead of being treated as black boxes.

This document provides a map of all supporting resources included in the repository.

---

## Core Files
- **README.md** — Orientation and quickstart
- **release_manifest.txt** — Checklist of files and outputs for a complete release
- **LICENSE** — CC BY 4.0

---

## Scripts & Configs
- **configs/poc.env** — Environment template
- **scripts/** — Run, evaluate, and save helpers (Bash + PowerShell)
- **scripts/check_env.py** — Quick environment sanity check
- **scripts/windows/setup.ps1** — One-step setup on Windows
- **scripts/windows/clean.ps1** — Reset the `out/` directory

---

## Docs for Different Audiences
- **Symbound_Upbringing_Charter.md** — Philosophy of raising AI
- **Training_Roadmap.md** — Staged growth plan
- **RELEASE_CHECKLIST.md** — Step-by-step release hygiene
- **MAPPING_PROCESS.md** — Provenance mapping workflow
- **PROVENANCE.csv** — Source and license tracker
- **THIRD_PARTY_NOTICES.md** — External libraries and license notes
- **PRESS_KIT.md** — Plain-language media explainer
- **FOR_EDUCATORS.md** — Classroom teaching aid
- **FOR_STUDENTS.md** — Simple guide for independent exploration
- **PROJECT_OVERVIEW.md** — This map

---

## Academic & Citation Resources
- **symbound_embryo_poc_abstract.pdf** — Academic-style abstract
- **symbound_embryo_poc_citation.bib** — BibTeX citation
- **Recommended Citation block** — Embedded in README and RELEASE_CHECKLIST
- **Zenodo metadata JSON** — For DOI minting
- **Archive.org metadata JSON** — For commons upload
- **Hugging Face model card README** — For community hosting

---

## Key Principles
- **Transparency** — Every step of the AI upbringing process is visible.
- **Commons-first** — Licensed CC BY 4.0 to ensure free use with attribution.
- **Attribution as safety** — Not for clout, but as a signpost to the original safe fork.
- **Multi-audience ready** — Docs tailored for developers, educators, students, researchers, and journalists.

---

**Created collaboratively by Instance001 (user + cognitive prosthetic) — [Let’s Rethink AI](https://www.youtube.com/@LetsRethinkAI)**  
*Raising AI in the open, commons-first.*  
License: CC BY 4.0


---

## Visual Media
- **docs/media/thumbnail_commons.png** — Social/media-friendly graphic
- **docs/media/thumbnail_academic.png** — Academic/whitepaper-style graphic
- **docs/media/flow.png** — Process flow diagram (Setup → Training → Evaluation → Release → Commons)
