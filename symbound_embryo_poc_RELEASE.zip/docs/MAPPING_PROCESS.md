# Mapping Process → Commons Release
_A repeatable workflow to consolidate fragmented sources into a single, license‑clean, commons‑ready package._

## Goals
- Preserve provenance for every included piece
- Normalize structure and naming
- Reconcile licenses so downstream users can reuse safely
- Output a clean tree + manifest suitable for public commons

## Workflow (10 steps)

1) **Ingest**
   - Collect source files (notes, scripts, images, gists, chats, GitHub refs).
   - Store raw drops under `mapping_ingest/` (do not ship this folder).

2) **Provenance table**
   - Create `docs/PROVENANCE.csv` with columns:
     - `path_in_repo`, `source_uri_or_author`, `date_collected`, `license`, `changes_made`, `notes`

3) **License reconciliation**
   - For each item, record its license.
   - If unknown, treat as **needs-replacement** or rewrite in your own words.
   - Prefer permissive licenses (MIT/Apache-2.0/CC0/CC‑BY).
   - Avoid viral terms if they conflict with your intended repo license.

4) **Normalization**
   - Convert to UTF‑8 text where possible.
   - Normalize line endings (`\n`), remove BOMs.
   - Rename files to lowercase‑kebab or snake_case.

5) **Deduplication**
   - Identify and merge near‑duplicates, keep the clearest version.
   - Note decisions in the provenance table (`changes_made`).

6) **Stitching**
   - Consolidate related fragments into canonical docs (e.g., `README.md`, `docs/*.md`).
   - Keep commit messages meaningful (what was merged, from where).

7) **Sensitive data sweep**
   - Scan for keys/secrets/PII. Remove or redact.
   - Add `.gitignore` patterns for any local scratch paths.

8) **Manifest & checklist**
   - Update `release_manifest.txt` and `docs/RELEASE_CHECKLIST.md` any time the expected outputs change.

9) **License files**
   - Ensure a single `LICENSE` governs the repo content you authored.
   - For third‑party snippets, include attribution in the file header or in `docs/THIRD_PARTY_NOTICES.md`.

10) **Final validation**
   - Fresh venv run succeeds.
   - `out/` artifacts present (or explicitly omitted for source‑only).
   - Checksums generated for the public zip.

## Template: PROVENANCE.csv
```csv
path_in_repo,source_uri_or_author,date_collected,license,changes_made,notes
docs/Training_Roadmap.md,https://github.com/your_org/your_repo/...,2025-10-05,CC-BY-4.0,"light edit, normalized headings",""
scripts/run_poc.sh,authored by Instance001,2025-10-05,MIT,"added shebang, comments",""
```
