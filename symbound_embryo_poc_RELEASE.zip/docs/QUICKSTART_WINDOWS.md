# QUICKSTART (Windows — zero fuss)

1. Right‑click **Start**, open **PowerShell**.
2. `cd` into this folder (where `README.md` lives).
3. Run setup:
   ```powershell
   .\scripts\windows\setup.ps1
   ```
4. Run the tiny POC:
   ```powershell
   .\scripts\windows\run_poc.ps1
   ```
5. Evaluate + produce the training card:
   ```powershell
   .\scripts\windows\eval_poc.ps1
   ```
6. Save artifacts (collects outputs into `out/`):
   ```powershell
   .\scripts\windows\save_artifacts.ps1
   ```

If anything fails, close the window, reopen PowerShell, and try again fresh.


---

## One-click run (Windows)
Double-click **run_everything.bat** in the repo root.
It will setup → train → evaluate → freeze env → save artifacts → run integrity checks → package a release zip.
