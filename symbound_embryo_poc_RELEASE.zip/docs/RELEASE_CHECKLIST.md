# Symbound Embryo — RELEASE CHECKLIST
_A tidy, copy/paste-friendly pipeline for cutting a reproducible POC release._

> **Scope:** This is for the tiny, hobby‑safe “embryo” training POC. It assumes a single Windows PC or Linux/macOS box.  
> **Goal:** Produce a minimal, commons‑ready zip with artifacts + exact environment for anyone to replicate.

---

## 0) Preflight
- ✅ Hardware sanity (toy scale): CPU‑only or small GPU is fine.
- ✅ Python 3.10+ installed
- ✅ Git + PowerShell (Windows) or Bash (Linux/macOS)
- ✅ Optional: Create and activate a virtual environment

**Linux/macOS (bash):**
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

**Windows (PowerShell):**
```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

> If this is a first run, `requirements.txt` is a starter; after a successful run, we’ll pin via `pip freeze` below.

---

## 1) Configure
Edit `configs/poc.env` to match your setup. The defaults are safe for demo:
- `DEVICE=cpu` (set to `cuda` if you have it)
- `DATA_DIR=./data` containing toy `train.jsonl` and `val.jsonl`
- `OUT_DIR=./out` for logs, checkpoints, and cards

---

## 2) Run the POC
**Linux/macOS:**
```bash
bash scripts/run_poc.sh
```

**Windows (PowerShell):**
```powershell
.\scripts\windowsun_poc.ps1
```

> Success criteria: `./out/poc.log` exists, loss is sane (no NaN), and a tiny checkpoint lands in `./out/ckpts` (names may vary).

---

## 3) Evaluate (Training Card)
Generates a compact “training_card.md” summarizing run + quick metrics.

**Linux/macOS:**
```bash
bash scripts/eval_poc.sh
```

**Windows (PowerShell):**
```powershell
.\scripts\windows\eval_poc.ps1
```

Expected outputs:
- `./out/training_card.md`
- (optionally) `./out/predictions.jsonl`

---

## 4) Graduation Bundle (Optional)
If the toy run meets your “graduation” gates, stage the bundle metadata:

- `./out/graduation.yaml`
- `./out/graduation_test.jsonl`
- `./out/predictions.jsonl` (from evaluator)

> These are intentionally minimal; it’s the pattern that matters.

---

## 5) Freeze exact environment
Pin dependencies and capture your shell environment for reproduction.

**Linux/macOS (bash):**
```bash
pip freeze > requirements.txt
env | sort > CMD_env.txt
```

**Windows (PowerShell):**
```powershell
pip freeze | Out-File -Encoding ascii requirements.txt
Get-ChildItem Env: | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" } | Out-File -Encoding ascii CMD_env.txt
```

---

## 6) Save artifacts (one‑shot helper)
These helpers collect outputs into `./out/` and do light validation.

**Linux/macOS:**
```bash
bash scripts/save_artifacts.sh
```

**Windows (PowerShell):**
```powershell
.\scripts\windows\save_artifacts.ps1
```

Check that `out/` contains (names may vary slightly):
- `poc.log`
- `ckpts/` (tiny checkpoint/tokenizer)
- `training_card.md`
- `graduation.yaml` (optional)
- `graduation_test.jsonl` (optional)
- `predictions.jsonl` (optional)
- `requirements.txt`
- `CMD_env.txt`

---

## 7) Final zip (release candidate)
Create a fresh zip including **source + out/** and the license.

**Linux/macOS:**
```bash
zip -r symbound_embryo_poc_RELEASE.zip   .gitignore LICENSE README.md requirements.txt CMD_env.txt   configs scripts docs out
```

**Windows (PowerShell 5+):**
```powershell
Compress-Archive -Path @(
  '.gitignore','LICENSE','README.md','requirements.txt','CMD_env.txt',
  'configs','scripts','docs','out'
) -DestinationPath 'symbound_embryo_poc_RELEASE.zip' -Force
```

> If you prefer a source‑only zip (no artifacts), omit `out/`. For a **publish** release, we recommend **including** `out/` so others can verify before rerunning training.

---

## 8) Checksums (recommended)
Produce a simple `SHA256SUMS.txt` for the release zip.

**Linux/macOS:**
```bash
shasum -a 256 symbound_embryo_poc_RELEASE.zip > SHA256SUMS.txt
```

**Windows (PowerShell):**
```powershell
Get-FileHash symbound_embryo_poc_RELEASE.zip -Algorithm SHA256 | ForEach-Object {
  $_.Hash + "  symbound_embryo_poc_RELEASE.zip"
} | Out-File -Encoding ascii SHA256SUMS.txt
```

---

## 9) Before publishing — final checklist
- [ ] `README.md` updated (hardware, quickstart, post‑run artifacts section)  
- [ ] `configs/poc.env` present with sane defaults (no secrets)  
- [ ] `requirements.txt` pinned via `pip freeze` after run  
- [ ] `CMD_env.txt` captured  
- [ ] `out/` contains expected toy artifacts (or you’ve chosen source‑only)  
- [ ] `LICENSE` present and correct  
- [ ] `release_manifest.txt` matches what you’re shipping  
- [ ] `SHA256SUMS.txt` generated (optional but preferred)  
- [ ] Zip opens cleanly; sample commands tested on a fresh venv  

---

## 10) Publish
Attach the zip to GitHub release (or your chosen host) with a quick blurb:
- What this is (toy‑scale, hobby‑safe POC)
- Why it exists (substrate behavior + upbringing pattern demo)
- How to reproduce (point to this checklist + README)
- Credit: Symbound Embryo POC by Instance001 (user + cognitive prosthetic) under the listed license.

---

📖 **Recommended Citation**

Instance001 (user + cognitive prosthetic), & Let’s Rethink AI. (2025, October 5).  
*Symbound Embryo — Proof-of-Concept (POC).*  
Zenodo / Archive.org / Hugging Face.  
https://archive.org/details/symbound-embryo-poc  

License: CC BY 4.0 — Raising AI in the open, commons-first.
