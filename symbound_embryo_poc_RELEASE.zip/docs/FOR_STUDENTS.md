# For Students — Exploring the Symbound Embryo POC

## What this is
The *Symbound Embryo Proof-of-Concept (POC)* is a small, safe AI project.  
It shows how AI models are created step by step — not as a black box, but as a clear process.  
You don’t need a powerful computer or advanced skills to try it.  

## Why it matters
AI is shaping the world around us. This project helps you see how it starts — with data, training, 
evaluation, and sharing — in a way that is **transparent, ethical, and reproducible**.  
By exploring it, you’ll learn how to think about AI as something people raise and guide, not as 
mysterious magic.

## How to explore
1. **Get started**  
   - Open PowerShell (Windows) or Terminal (Mac/Linux).  
   - Run the setup script:  
     ```powershell
     .\scripts\windows\setup.ps1
     ```  
     or  
     ```bash
     make venv
     ```

2. **Train the tiny model**  
   - Windows:  
     ```powershell
     .\scripts\windows\run_poc.ps1
     ```  
   - Linux/Mac:  
     ```bash
     make run
     ```

   This will create a small log file in `out/poc.log` and save a “checkpoint” — a snapshot of the model’s learning.

3. **Evaluate**  
   - Run the evaluation script to generate `training_card.md`.  
   - This card shows what happened in training and helps track results.

4. **Look around**  
   - Check out the `docs/` folder: it has a charter (the philosophy), a roadmap (the steps), 
     and a press kit (plain-language explainer).

## What you’ll learn
- How AI models are trained, even at toy scale.  
- Why it’s important to record and share provenance (where things come from).  
- How attribution keeps projects safe and commons-aligned.  

## Remember
This project is licensed under **CC BY 4.0**.  
That means you can use it freely, as long as you give credit:

**Instance001 (user + cognitive prosthetic), & Let’s Rethink AI (2025). Symbound Embryo — Proof-of-Concept (POC).**

---

✨ Tip: If something breaks, don’t panic. Just restart PowerShell/Terminal and try again.  
Exploring is about learning by doing — mistakes are part of the process!
