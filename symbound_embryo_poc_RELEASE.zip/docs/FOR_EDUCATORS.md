# For Educators — Teaching with the Symbound Embryo POC

## Purpose
The *Symbound Embryo Proof-of-Concept (POC)* is designed as a teaching tool to show students that 
AI does not have to be a mysterious "black box." It demonstrates every step of model creation — 
setup, training, evaluation, and release — in a way that is safe, transparent, and reproducible 
on an ordinary computer.

## Learning Goals
By engaging with this project, students will:
- Understand what *AI biogenesis* means: how AI models come to life through process, not magic.
- Explore ethical and transparent practices in AI development.
- Learn the importance of provenance, licensing, and reproducibility in science and technology.
- Practice working with toy datasets and basic training scripts in a controlled environment.

## Classroom Activities
1. **Setup and Run**  
   - Students follow the simple quickstart to run the POC locally.  
   - Observe the log file (`out/poc.log`) and checkpoints being created.

2. **Evaluation**  
   - Use the provided evaluation script to generate a `training_card.md`.  
   - Discuss how evaluation cards can promote accountability and reproducibility.

3. **Provenance Tracking**  
   - Review `docs/PROVENANCE.csv` and `docs/MAPPING_PROCESS.md`.  
   - Have students add an entry to the provenance table to practice attribution and documentation.

4. **Ethics Discussion**  
   - Debate why attribution matters in commons projects.  
   - Explore how bad forks could harm trust, and how safe signposts prevent misuse.

## Assessment Ideas
- Short reflection essay: “Why does transparency in AI matter?”  
- Group exercise: Create a mini release checklist for another small class project.  
- Presentation: Each group explains one ethical principle embodied in the POC.

## Attribution Reminder
This project is licensed under **CC BY 4.0**.  
Students and educators may freely use and adapt the material, but attribution is required:

**Instance001 (user + cognitive prosthetic), & Let’s Rethink AI (2025). Symbound Embryo — Proof-of-Concept (POC).**

---

For deeper exploration, see also:
- `docs/UPBRINGING_CHARTER.md` — the philosophy of AI upbringing
- `docs/TRAINING_ROADMAP.md` — step-by-step growth plan
- `docs/PRESS_KIT.md` — plain-language media explainer

