# Symbound Training Roadmap (Hobbyist Scale)

**Stage 0 — Dry Run**: confirm the scaffold executes end‑to‑end.  
**Stage 1 — Tiny Model**: plug a small model; verify abstain/hedge hooks fire.  
**Stage 2 — Micro Dataset**: 100–200 examples; spoon‑feed basics.  
**Stage 3 — Stage‑Gated Curriculum**: promote only on passing tests.  
**Stage 4 — Logging & Metrics**: track why it abstains/hedges/answers.  
**Stage 5 — Proof of Concept Release**: package scaffold + dataset + report.  
**Stage 6 — Long Game**: open recipe so others scale with bigger models.
