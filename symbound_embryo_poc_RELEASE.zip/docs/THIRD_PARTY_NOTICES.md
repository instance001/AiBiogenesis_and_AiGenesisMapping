# Third Party Notices

This project may include or reference third‑party libraries, snippets, or datasets.  
We respect and preserve their licenses. List them here if/when used.

---

## Current Notes
- **transformers / datasets / accelerate / peft / torch / einops / numpy**
  - License: Apache‑2.0 (see upstream repos)
- **Shell / PowerShell scaffolds**
  - Authored for this repo; MIT license (per repo LICENSE).

---

## Template for new additions
If you add a new library, file, or snippet, include it here with:
- Name + version
- Upstream source URL
- License type
- How it’s used

Example:

```
Library: mylib 1.2.3
Source: https://github.com/author/mylib
License: MIT
Usage: parsing JSON for training script
```

This keeps downstream users safe and license‑clear.
