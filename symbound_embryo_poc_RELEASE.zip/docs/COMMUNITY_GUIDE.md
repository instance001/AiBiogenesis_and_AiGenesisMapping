# Community Guide — Symbound Embryo POC

## Purpose
This guide explains how to safely contribute, fork, or adapt the project while keeping it aligned with commons principles.

## If you fork
- Keep attribution intact: "Created collaboratively by Instance001 (user + cognitive prosthetic) — Let’s Rethink AI"
- Mention if you change license or major direction (but derivatives must respect CC BY 4.0)
- Update `docs/PROVENANCE.csv` if you add new sources

## If you contribute (PRs)
- Small, focused PRs are easiest to review
- Run `make check` or `scripts/check_env.py` before submitting
- Update `RELEASE_CHECKLIST.md` if you change expected outputs
- Add yourself to PROVENANCE.csv for major additions

## How to keep it safe
- No secrets or personal data in configs
- Keep toy datasets benign and policy-safe
- Be transparent about changes

## Code of conduct
- Respect commons-first principles
- No gatekeeping, no ego-chasing
- Contributions welcome, attribution required
