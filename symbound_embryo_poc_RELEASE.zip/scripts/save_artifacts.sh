#!/usr/bin/env bash
set -euo pipefail
RUN_DIR="runs/poc-2025-10-05"
mkdir -p "$RUN_DIR"
echo "[symbound] gathering artifacts → $RUN_DIR"

# Common artifacts (best‑effort; ignore if missing)
cp -f symbound_bpe.json "$RUN_DIR" 2>/dev/null || true
cp -rf out "$RUN_DIR/out" 2>/dev/null || true
cp -f training_card.md "$RUN_DIR" 2>/dev/null || true
cp -f graduation.yaml graduation_test.jsonl predictions.jsonl "$RUN_DIR" 2>/dev/null || true
pip freeze > "$RUN_DIR/requirements.txt" || true
cp -f CMD_env.txt "$RUN_DIR" 2>/dev/null || true

echo "Artifacts collected. Zip and publish this folder with the manifest."
