#!/usr/bin/env bash
set -euo pipefail
if [ ! -f evaluator.py ]; then
  echo "evaluator.py not found in current directory"; exit 1
fi
python3 evaluator.py   --ground graduation_test.jsonl   --pred predictions.jsonl   --cfg graduation.yaml   --out training_card.md
echo "[symbound] wrote training_card.md"
