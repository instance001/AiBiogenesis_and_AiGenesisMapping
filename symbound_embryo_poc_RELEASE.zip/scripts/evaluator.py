import os, time, pathlib

out = pathlib.Path("out"); out.mkdir(exist_ok=True)
log_p = out / "poc.log"
log_txt = log_p.read_text(encoding="utf-8", errors="ignore") if log_p.exists() else ""
card = (
    "# Training Card\n\n"
    f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    "Summary:\n"
    "- Tiny training executed.\n"
    f"- Log bytes: {len(log_txt)}\n"
)
(out / "training_card.md").write_text(card, encoding="utf-8")
print("Wrote out/training_card.md")