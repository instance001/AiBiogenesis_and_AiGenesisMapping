param()
$ErrorActionPreference = 'Continue'
Write-Host "[symbound] collecting artifacts into .\out"

# Keep ASCII only to avoid parser issues
# Example artifact copies (uncomment if present):
# Copy-Item -Force -ErrorAction SilentlyContinue .\requirements.txt .\out\
# Copy-Item -Force -ErrorAction SilentlyContinue .\CMD_env.txt .\out\