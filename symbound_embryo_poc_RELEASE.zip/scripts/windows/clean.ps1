# Remove and recreate the out/ directory safely
Write-Host "==> Cleaning out/"
if (Test-Path .\out) { Remove-Item -Recurse -Force .\out }
New-Item -ItemType Directory -Force -Path .\out | Out-Null
New-Item -ItemType File -Force -Path .\out\.gitkeep | Out-Null
Write-Host "Done."
