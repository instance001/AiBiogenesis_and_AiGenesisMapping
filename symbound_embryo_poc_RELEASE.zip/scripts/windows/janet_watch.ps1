# Janet watcher: runs training and watches the log for NaNs or loss explosions
$log = ".\out\poc.log"
# Start a background job that tails the log and stops if unhealthy
$script = {
    param($LogPath)
    $lastLoss = $null
    while ($true) {
        if (Test-Path $LogPath) {
            Get-Content -Path $LogPath -Wait -Tail 5 | ForEach-Object {
                $_ | Out-Host
                if ($_ -match "NaN|nan") {
                    Write-Host "[janet] Detected NaN → stopping run." -ForegroundColor Red
                    Stop-Process -Name "bash" -Force -ErrorAction SilentlyContinue
                }
                if ($_ -match "loss[:=]\s*([0-9\.Ee\-]+)") {
                    $curr = [double]$Matches[1]
                    if ($lastLoss -ne $null) {
                        if ($curr -gt ($lastLoss * 5)) {
                            Write-Host "[janet] Loss spike ($lastLoss → $curr) → stopping run." -ForegroundColor Yellow
                            Stop-Process -Name "bash" -Force -ErrorAction SilentlyContinue
                        }
                    }
                    $lastLoss = $curr
                }
            }
        } else {
            Start-Sleep -Milliseconds 200
        }
    }
}
$job = Start-Job -ScriptBlock $script -ArgumentList $log

# Kick off the normal run
.\symbound_embryo_poc\scripts\windows\run_poc.ps1

# Clean up watcher
Stop-Job $job -ErrorAction SilentlyContinue | Out-Null
Receive-Job $job -ErrorAction SilentlyContinue | Out-Null
Remove-Job $job -ErrorAction SilentlyContinue | Out-Null
