# Tiny, hobby-safe Symbound run (Windows, PowerShell)
# Expects: you're in C:\symbound with corpora + make_symbound_embryo.sh + evaluator.py

$env:VOCAB_SIZE = "8192"
$env:CORPUS     = "C:\symbound\corpus_full.txt"   # switch to corpus_starter.txt if you want extra small
$env:MODEL_SIZE = "small"
$env:TRAINER    = "abstain"
$env:DATASET    = "micro_plus"
$env:EPOCHS     = "20"
$env:DEVICE     = "cpu"
$env:CTX        = "192"
$env:BS         = "4"
$env:SELF_EVERY = "20"

# snapshot env for reproducibility
@"
VOCAB_SIZE=$env:VOCAB_SIZE
CORPUS=$env:CORPUS
MODEL_SIZE=$env:MODEL_SIZE
TRAINER=$env:TRAINER
DATASET=$env:DATASET
EPOCHS=$env:EPOCHS
DEVICE=$env:DEVICE
CTX=$env:CTX
BS=$env:BS
SELF_EVERY=$env:SELF_EVERY
"@ | Set-Content -Path ".\CMD_env.txt" -Encoding UTF8

# log path
$log = ".\out\poc.log"
New-Item -ItemType Directory -Force -Path ".\out" | Out-Null

Write-Host "[symbound] starting tiny training (device=$env:DEVICE, epochs=$env:EPOCHS, bs=$env:BS, ctx=$env:CTX)"
# Use Git Bash or WSL if bash isn't present. On Windows with Git installed, 'bash' is available.
if (Get-Command bash -ErrorAction SilentlyContinue) {
  bash ./make_symbound_embryo.sh *>> $log
} else {
  Write-Host "[symbound] (skip) bash not found; continuing on Windows"
}
Write-Host "[symbound] training finished. Log: $log"
