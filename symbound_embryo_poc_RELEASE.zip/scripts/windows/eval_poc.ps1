Write-Host "[symbound] generating training_card.md ..."
$ErrorActionPreference = 'Stop'
if (Test-Path .\scripts\evaluator.py) {
  python .\scripts\evaluator.py *>> $log
} else {
  Write-Error "evaluator.py not found at .\scripts\evaluator.py"
}