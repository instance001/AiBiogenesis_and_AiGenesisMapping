# Symbound Embryo — Windows Setup Helper
param(
    [string]$Python = "python",
    [string]$VenvPath = ".\.venv"
)

Write-Host "==> Creating virtual environment at $VenvPath"
& $Python -m venv $VenvPath
. "$VenvPath\Scripts\Activate.ps1"

Write-Host "==> Installing requirements"
pip install -r requirements.txt

# Ensure scaffold dirs
New-Item -ItemType Directory -Force -Path .\data | Out-Null
New-Item -ItemType Directory -Force -Path .\out  | Out-Null

Write-Host "==> Setup complete. Try:"
Write-Host "   .\scripts\windows\run_poc.ps1"
