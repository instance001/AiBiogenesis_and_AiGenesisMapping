param()

$ErrorActionPreference = 'Continue'
Write-Host "[symbound] freezing environment..."

# Ensure out exists
if (!(Test-Path .\out)) { New-Item -ItemType Directory -Path .\out | Out-Null }

# Write requirements.txt at repo root
if (Test-Path .\.venv\Scripts\python.exe) {
  .\.venv\Scripts\python.exe -m pip freeze > .\requirements.txt
} else {
  python -m pip freeze > .\requirements.txt
}

# Write a minimal environment capture
$pycmd = @'
import platform, sys
with open("CMD_env.txt","w", encoding="utf-8") as f:
    f.write("python="+platform.python_version()+"\n")
    f.write("platform="+platform.platform()+"\n")
    f.write("implementation="+platform.python_implementation()+"\n")
    f.write("executable="+sys.executable+"\n")
print("Wrote requirements.txt and CMD_env.txt")
'@

if (Test-Path .\.venv\Scripts\python.exe) {
  .\.venv\Scripts\python.exe -c $pycmd
} else {
  python -c $pycmd
}

Write-Host "[symbound] freeze complete."
