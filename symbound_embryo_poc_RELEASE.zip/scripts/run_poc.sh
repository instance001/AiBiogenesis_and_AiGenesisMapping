#!/usr/bin/env bash
set -euo pipefail
: "${VOCAB_SIZE:?}"
: "${CORPUS:?}"
: "${MODEL_SIZE:?}"
: "${TRAINER:?}"
: "${DATASET:?}"
: "${EPOCHS:?}"
: "${DEVICE:?}"
: "${CTX:?}"
: "${BS:?}"
: "${SELF_EVERY:?}"

echo "[symbound] starting tiny training (device=$DEVICE, epochs=$EPOCHS, bs=$BS, ctx=$CTX)"
env | grep -E '^(VOCAB_SIZE|CORPUS|MODEL_SIZE|TRAINER|DATASET|EPOCHS|DEVICE|CTX|BS|SELF_EVERY)=' | sort > CMD_env.txt

# Delegate to your existing script (expected in current project root)
bash ./make_symbound_embryo.sh
echo "[symbound] training done."
