import sys, platform, json

report = {
    "python_version": sys.version.split()[0],
    "platform": platform.platform(),
}

def try_import(name):
    try:
        mod = __import__(name)
        return True, mod
    except Exception as e:
        return False, str(e)

mods = {}
for pkg in ["torch", "transformers", "datasets", "accelerate", "peft", "einops", "numpy"]:
    ok, val = try_import(pkg)
    mods[pkg] = "ok" if ok else f"missing ({val})"

report["packages"] = mods

# Torch details
if mods.get("torch") == "ok":
    import torch
    report["torch"] = {
        "version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "device_count": torch.cuda.device_count() if torch.cuda.is_available() else 0,
        "mps_available": getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available()
    }
else:
    report["torch"] = None

print(json.dumps(report, indent=2))
