
import os, json, re, sys, datetime, argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES_BASE = [
    'README.md',
    'LICENSE',
    'NOTICE',
    'release_manifest.txt',
    'configs/poc.env',
    'data/train.jsonl',
    'data/val.jsonl',
    'docs/Symbound_Upbringing_Charter.md',
    'docs/Training_Roadmap.md',
    'docs/RELEASE_CHECKLIST.md',
    'docs/MAPPING_PROCESS.md',
    'docs/PROVENANCE.csv',
    'docs/THIRD_PARTY_NOTICES.md',
    'docs/PROJECT_OVERVIEW.md',
    'docs/PRESS_KIT.md',
    'docs/FOR_EDUCATORS.md',
    'docs/FOR_STUDENTS.md',
    'docs/media/thumbnail_commons.png',
    'docs/media/thumbnail_academic.png',
    'docs/media/flow.png',
    '.github/workflows/ci.yml',
    '.githooks/pre-commit',
    'Makefile',
    'scripts/check_env.py',
]

RECOMMENDED_FILES = [
    'archive/HOWTO_UPLOAD.md',
    'archive/metadata.json',
    'INSTALL_HOOKS.md',
    'requirements.txt'
]

# Artifacts expected after a successful run (release profile)
RELEASE_ARTIFACTS = [
    'out/poc.log',
    'out/ckpts',                 # directory
    'out/training_card.md',
    'out/graduation.yaml',
    'out/graduation_test.jsonl',
    'out/predictions.jsonl',
    'CMD_env.txt',
    'symbound_embryo_poc_release.zip'
]

FOOTER_PATTERN = r"Created collaboratively by Instance001 \\(user \\+ cognitive prosthetic\\).*CC BY 4\\.0"

def exists(rel):
    p = (ROOT / rel)
    return p.exists()

def read(rel, default=""):
    try:
        return (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return default

def check_footer(text):
    return re.search(FOOTER_PATTERN, text, flags=re.IGNORECASE|re.DOTALL) is not None

def check_recommended_citation(text):
    return "Recommended Citation" in text and "Symbound Embryo" in text

def parse_manifest():
    text = read('release_manifest.txt')
    lines = [ln.strip() for ln in text.splitlines() if ln.strip() and not ln.strip().startswith('#')]
    manifest_files = [ln for ln in lines if '/' in ln or '.' in ln]
    return manifest_files

def main():
    ap = argparse.ArgumentParser(description="Symbound Integrity Check")
    ap.add_argument("--profile", choices=["source", "release"], default="source",
                    help="source: ignore expected post-run artifacts; release: require them")
    args = ap.parse_args()

    required = list(REQUIRED_FILES_BASE)
    problems = []

    # Profile-specific expectations
    if args.profile == "release":
        required += RELEASE_ARTIFACTS

    report = {
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'root': str(ROOT),
        'profile': args.profile,
        'required': {},
        'recommended': {},
        'readme_footer_ok': False,
        'readme_citation_ok': False,
        'charter_footer_ok': False,
        'manifest_check': {},
        'problems': problems
    }

    # Required files present
    for rel in required:
        ok = exists(rel)
        report['required'][rel] = ok
        if not ok:
            problems.append(f'Missing required ({args.profile}): {rel}')

    # Recommended files
    for rel in RECOMMENDED_FILES:
        report['recommended'][rel] = exists(rel)

    # README checks
    readme = read('README.md')
    report['readme_footer_ok'] = check_footer(readme)
    report['readme_citation_ok'] = check_recommended_citation(readme)
    if not report['readme_footer_ok']:
        problems.append('README missing Instance001 + CC BY footer')
    if not report['readme_citation_ok']:
        problems.append('README missing Recommended Citation block')

    # Charter footer
    charter = read('docs/Symbound_Upbringing_Charter.md')
    report['charter_footer_ok'] = check_footer(charter)
    if not report['charter_footer_ok']:
        problems.append('Charter missing attribution footer')

    # Manifest parsing (advisory)
    manifest_files = parse_manifest()
    missing_from_manifest = [p for p in manifest_files if not exists(p)]
    report['manifest_check'] = {
        'expected_count': len(manifest_files),
        'missing': missing_from_manifest
    }
    # Only treat manifest-missing as problems in release profile
    if args.profile == "release":
        for p in missing_from_manifest:
            problems.append(f'Manifest listed but not present: {p}')

    # Write reports
    out_dir = ROOT / 'out'
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f'integrity_report_{args.profile}.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

    md_lines = ["# Integrity Report",
                f"Generated: {report['timestamp']}",
                f"Profile: {args.profile}", ""]
    md_lines.append("## Required Files")
    for k, v in sorted(report['required'].items()):
        md_lines.append(f"- [{'x' if v else ' '}] {k}")
    md_lines.append("")
    md_lines.append("## Recommended Files")
    for k, v in sorted(report['recommended'].items()):
        md_lines.append(f"- [{'x' if v else ' '}] {k}")
    md_lines.append("")
    md_lines.append("## README Checks")
    md_lines.append(f"- Footer present: {'✅' if report['readme_footer_ok'] else '❌'}")
    md_lines.append(f"- Recommended Citation present: {'✅' if report['readme_citation_ok'] else '❌'}")
    md_lines.append("")
    md_lines.append("## Charter Footer")
    md_lines.append(f"- Present: {'✅' if report['charter_footer_ok'] else '❌'}")
    md_lines.append("")
    md_lines.append("## Manifest (advisory in source, required in release)")
    mc = report['manifest_check']
    md_lines.append(f"- Entries parsed: {mc.get('expected_count', 0)}")
    missing = mc.get('missing', [])
    if missing:
        md_lines.append(f"- Missing ({len(missing)}):")
        for p in missing[:25]:
            md_lines.append(f"  - {p}")
        if len(missing) > 25:
            md_lines.append(f"  - ... and {len(missing)-25} more")
    else:
        md_lines.append("- All manifest items present ✅")
    md_lines.append("")
    if problems:
        md_lines.append("## Problems")
        for p in problems:
            md_lines.append(f"- {p}")
    else:
        md_lines.append("## Problems")
        md_lines.append("- None — all checks passed ✅")

    (out_dir / f'integrity_report_{args.profile}.md').write_text("\n".join(md_lines), encoding='utf-8')

    # Exit code depends on problems
    sys.exit(1 if problems else 0)

if __name__ == '__main__':
    main()
